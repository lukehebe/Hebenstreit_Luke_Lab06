import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PizzaGUIFrame extends JFrame implements ActionListener {

    private JRadioButton thinCrustRadio, regularCrustRadio, deepDishCrustRadio;
    private JComboBox<String> sizeComboBox;
    private JCheckBox pepperoniCheckBox, sausageCheckBox, mushroomCheckBox, oliveCheckBox, onionCheckBox, pineappleCheckBox;
    private JTextArea orderTextArea;

    public PizzaGUIFrame() {
        setTitle("Pizza Order");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);

        JPanel crustPanel = createCrustPanel();
        JPanel sizePanel = createSizePanel();
        JPanel toppingPanel = createToppingPanel();
        JPanel orderPanel = createOrderPanel();
        JPanel buttonPanel = createButtonPanel();
        
        add(crustPanel, BorderLayout.NORTH);
        add(sizePanel, BorderLayout.WEST);
        add(toppingPanel, BorderLayout.CENTER);
        add(orderPanel, BorderLayout.EAST);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JPanel createCrustPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Crust"));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        thinCrustRadio = new JRadioButton("Thin");
        regularCrustRadio = new JRadioButton("Regular");
        deepDishCrustRadio = new JRadioButton("Deep-dish");
        ButtonGroup group = new ButtonGroup();
        group.add(thinCrustRadio);
        group.add(regularCrustRadio);
        group.add(deepDishCrustRadio);
        panel.add(thinCrustRadio);
        panel.add(regularCrustRadio);
        panel.add(deepDishCrustRadio);
        return panel;
    }

    private JPanel createSizePanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Size"));
        String[] sizes = {"Small", "Medium", "Large", "Super"};
        sizeComboBox = new JComboBox<>(sizes);
        panel.add(sizeComboBox);
        return panel;
    }

    private JPanel createToppingPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Toppings"));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        pepperoniCheckBox = new JCheckBox("Pepperoni");
        sausageCheckBox = new JCheckBox("Sausage");
        mushroomCheckBox = new JCheckBox("Mushroom");
        oliveCheckBox = new JCheckBox("Olive");
        onionCheckBox = new JCheckBox("Onion");
        pineappleCheckBox = new JCheckBox("Pineapple");
        panel.add(pepperoniCheckBox);
        panel.add(sausageCheckBox);
        panel.add(mushroomCheckBox);
        panel.add(oliveCheckBox);
        panel.add(onionCheckBox);
        panel.add(pineappleCheckBox);
        return panel;
    }

    private JPanel createOrderPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Order"));
        orderTextArea = new JTextArea(20, 20);
        JScrollPane scrollPane = new JScrollPane(orderTextArea);
        panel.add(scrollPane);
        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel();
        JButton orderButton = new JButton("Order");
        orderButton.addActionListener
